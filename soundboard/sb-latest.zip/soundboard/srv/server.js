/* (c) 2020 C.J.Schmitt */

var connect = require('connect');
var serveStatic = require('serve-static');
var fs = require('fs');
var NodeID3 = require('node-id3');

var tracks = [];
var appdir = '../fsvSoundBoard/dist/fsvSoundBoard';
var mp3Dir = appdir + '/assets/tracks/';

var scanActive = false;

if (process.argv.length > 3) {
    for (var i = 2; i < process.argv.length; i++) {
        var param = process.argv[i];
        if (param.indexOf('--a=') === 0) {
            appdir = param.substring(4).replace(/"/g, '');
        }
        else if (param.indexOf('--m=') === 0) {
            mp3Dir = param.substring(4).replace(/"/g, '');
            if (!mp3Dir.endsWith('/')) {
                mp3Dir += '/';
            }
        }
    }
}

function mayReadMeta(mp3File) {
    var filePath = mp3Dir + mp3File + '.json';
    try {
        if (fs.existsSync(filePath)) {
            return JSON.parse(fs.readFileSync(filePath));
        }
    } catch (error) { }
    return {};
}

function readMp3(file) {
    var tags = NodeID3.read(mp3Dir + file);
    var composed = '';

    if (tags.artist) {
        composed = tags.artist + ' > ';
    }
    if (tags.title) {
        composed += tags.title;
    }
    else if (tags.length === 0) {
        composed = file.substring(0, file.lastIndexOf('.'));
    }
    return composed;
}

function scanForMp3s() {
    if (scanActive) {
        return;
    }
    else {
        scanActive = true;
        fs.readdir(mp3Dir, (err, files) => {
            tracks = [];
            console.log(' - scanning mp3 files in ' + mp3Dir + '\n');
            if (files) {
                files.forEach(file => {
                    if (file.endsWith('.mp3')) {
                        var meta = mayReadMeta(file);
                        meta.file = file;
                        meta.title = readMp3(file);
                        tracks.push(meta);
                        console.log(' + ' + meta.title);
                    }
                });
            }
            else {
                console.log('!! no files found, may wrong directory was given');
            }
            console.log('\n+++ Open SoundBoard App on http://localhost:8080 +++\n');
            scanActive = false;
        });
    }
}

function serveTracksJson(req, res, next) {
    console.log(' - Serving ' + tracks.length + ' tracks ');
    res.write(JSON.stringify(tracks));
    res.end();
}

function serveMp3(req, res, next) {
    var mp3File = req.url.indexOf('/') === 0 ? req.url.substring(1) : req.url;
    mp3File = decodeURIComponent(mp3File);
    console.log(' - Serving mp3', mp3File);
    var filePath = mp3Dir + mp3File
    res.write(fs.readFileSync(filePath));
    res.end();
}

function saveMeta(req, res, next) {
    let body = '';
    req.on('data', chunk => {
        body += chunk.toString();
    });
    req.on('end', () => {
        try {
            var meta = JSON.parse(body);
            var volume = Number.parseFloat(meta.volume);
            var start = Number.parseFloat(meta.start);
            var trackMeta = {
                start: start,
                volume: volume
            };
            fs.writeFileSync(mp3Dir + meta.file, JSON.stringify(trackMeta));
            console.log('- Saving meta ->', meta.file, JSON.stringify(trackMeta));
        } catch (error) { }
        res.end();
    });
}

if (!fs.existsSync(mp3Dir)) {
    console.error('!! given mp3 directory does not exist', mp3Dir);
}
else {
    scanForMp3s();

    fs.watch(mp3Dir, (eventType, filename) => {
        scanForMp3s();
    })

    console.log(' - serving sound board app from directory', appdir);

    connect()
        .use('/assets/tracks.json', serveTracksJson)
        .use('/assets/mp3', serveMp3)
        .use('/assets/saveMeta', saveMeta)
        .use(serveStatic(appdir))
        .listen(8080, 'localhost', function () {
            console.log('+++ Server running on port 8080... -> http://localhost:8080 +++\n');
        });
}
